<?php
session_start();
$_SESSION=array();
session_destroy();
?>
<!DOCTYPE html>
<html>
<head>
<title>Deconnexion</title>
<meta charset="utf-8" />
<link rel="stylesheet" type="text/css" href="../CSS/style1.css">
<head>
	<title>Deconnexion</title>
	<meta charset="utf-8">
</head>
<body>
	vous êtes bien déconecté...
	<a href="../login_ent.php">Retour à l'accueil</a>
</body>