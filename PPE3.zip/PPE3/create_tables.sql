/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  florian
 * Created: 28 sept. 2016
 */

drop table entreprises_demande;
drop table entreprises;
drop table type_entreprises;
drop table enseignant;
drop table etudiant;
drop table utilisateur;

create table utilisateur (
	id_utilisateur int primary key,
	statut varchar(10)
);

create table etudiant (
	e_code int primary key,
	login char(8),
	mdp char(8),
	et_nom varchar(20),
	et_prenom varchar(20),
	et_mail varchar(30),
    id_utilisateur_et int,
	constraint fk_etudiant_id_utilisateur foreign key (id_utilisateur_et) references utilisateur (id_utilisateur)
);

create table enseignant (
	e_code int primary key,
	login char(8),
	mdp char(8),
	en_nom varchar(20),
	en_prenom varchar(20),
	en_mail varchar(30),
    id_utilisateur_en int,
	constraint fk_enseignant_id_utilisateur foreign key (id_utilisateur_en) references utilisateur (id_utilisateur)
);

create table type_entreprises (
	te_code int primary key,
	te_libelle varchar(100)
);

create table entreprises (
	e_code int primary key not null AUTO_INCREMENT,
        e_nom varchar(20),
        e_adresse1 varchar(100),
        e_adresse2 varchar(100),
		e_ville varchar(20),
        e_codpostal char(5),
        e_nom_correspondant varchar(20),
        e_tel char(10),
        e_mail varchar(20),
        e_statut varchar(20),
        te_code int,
        constraint fk_type_entreprises_te_code foreign key (te_code) references type_entreprises (te_code)
);

create table entreprises_demande (
        e_code_dem int primary key not null AUTO_INCREMENT,
        e_nom_dem varchar(20),
        e_adresse1_dem varchar(100),
        e_adresse2_dem varchar(100),
		e_ville_dem varchar(20),
        e_codpostal_dem char(5),
        e_nom_correspondant_dem varchar(20),
        e_tel_dem char(10),
        e_mail_dem varchar(20),
        e_statut_dem varchar(20),
     --   et_code int,
		te_code_dem int,
       -- en_code int,
       -- constraint fk_enseignant_en_code foreign key (en_code) references enseignant (en_code),
	   constraint fk_type_entreprises_te_code_dem foreign key (te_code_dem) references type_entreprises (te_code)
    --    constraint fk_etudiant_et_code foreign key (et_code) references etudiant(e_code)
);