<! DOCTYPE html>

<nav>
		<ul><li> 	<a href="../lister/liste_entV2.php">Entreprises</a></li>
			<li> 	<a href="../lister/liste_ent_demV2.php">demandes</a></li>
	</nav>