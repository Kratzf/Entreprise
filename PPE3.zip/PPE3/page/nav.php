<! DOCTYPE html>

<nav>
		<ul><li> 	<a href="../lister/afficherempV1.php">Entreprises</a></li>
			<li> 	<a href="../lister/afficherempV2.php">demandes</a></li>
	</nav>