<! DOCTYPE html>

<nav>
		<ul><li> 	<a href="../lister/liste_ent.php">Entreprises</a></li>
			<li> 	<a href="../lister/liste_ent_dem.php">demandes</a></li>
	</nav>