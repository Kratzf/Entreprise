<?php
session_start();
    $message="";

if (isset($_SESSION['e_code'])) {
			include '../BDD.php';
			$connexion=new BDD('entreprise');
			$e_code = $_SESSION['e_code']; 
    //passage première fois
	if (isset($_GET['id'])){
		$id=$_GET['id'];
		$requete="select * from entreprises where e_code=$id";
		echo $requete;
		$tab=$connexion->select($requete);
		$ligne=$tab[0];
		
		//attributs 
		
			$e_nom=$ligne['e_nom'];
			$e_adresse1=$ligne['e_adresse1'];
			$e_adresse2=$ligne['e_adresse2'];
			$e_ville=$ligne['e_ville'];
			$e_codpostal=$ligne['e_codpostal'];
			$e_nom_correspondant=$ligne['e_nom_correspondant'];
			$e_tel=$ligne['e_tel'];
			$e_mail=$ligne['e_mail'];
			$e_statut=$ligne['e_statut'];
			$te_code=$ligne['te_code'];	
   }
  else {
				$id = $_POST['id'];
						$e_nom=$_POST['e_nom'];
						$e_adresse1=$_POST['e_adresse1'];
						$e_adresse2=$_POST['e_adresse2'];
						$e_ville=$_POST['e_ville'];
						$e_codpostal=$_POST['e_codpostal'];
						$e_nom_correspondant=$_POST['e_nom_correspondant'];
						$e_tel=$_POST['e_tel'];
						$e_mail=$_POST['e_mail'];
						$e_statut=$_POST['e_statut'];
						$te_code=$_POST['te_code'];	
		
					$requete= "UPDATE entreprises SET e_nom='$e_nom', e_adresse1='$e_adresse1', e_adresse2='$e_adresse2',
					e_ville='$e_ville', e_codpostal='$e_codpostal', e_nom_correspondant='$e_nom_correspondant', e_tel='$e_tel', 
					e_statut='$e_statut', e_mail='$e_mail', te_code=$te_code WHERE e_code='$id'";
					 $message=$connexion->insert($requete);
		if($message==''){
			$message='mise à jour bien effectuée';
		}
	}
}
else {
			header("location:../login_ent.php");
		}
?>
<html>
<header>
<?php
include"../page/header.php";


?>
</header>
<body>
<?php
include"../page/nav.php";
?>
<head>
    <meta charset="utf-8">
<title>suivie entreprise</title>
<link rel="stylesheet" href="../CSS/style1.css" />
<style>
			.correct {
				border-color: rgba(68, 191, 68, 0.75);
			}
			.incorrect {
				border-color: rgba(191, 68, 68, 0.75);
			}
			
			.tooltip {
				display:none;
				margin-left: 20px;
				padding: 2px 4px;}
            </style>
</head>

 <h1>Modifier entreprise n°<?php echo $id; ?></h1>
	<form method="post" action="modifier_ent.php"> 
	 <input type='hidden' name='id' value='<?php echo $id; ?>'/>
		
			nom: <input type="text" name='e_nom' value="<?php echo $e_nom; ?>"/></br>
			adresse1: <input type="text" name='e_adresse1' value="<?php echo $e_adresse1;?>" /></br>
			adresse2: <input type="text" name='e_adresse2' value="<?php echo $e_adresse2;?>" /></br>
			ville: <input type="text" name='e_ville' value="<?php echo $e_ville;?>"/></br>
			nom correspondant: <input type="text" name='e_nom_correspondant' value="<?php echo $e_nom_correspondant; ?>" /></br>
			code postal: <input type="text" name='e_codpostal' value="<?php echo $e_codpostal;?>" /></br>
			telephone: <input type="text" name='e_tel' id='e_tel' value="<?php echo $e_tel; ?>" />
			<span class="tooltip" id="tooltip">Vous devez saisir un numéro de téléphone a 10 chiffres</span></br>
			mail: <input type="text" name='e_mail' id='e_mail' value="<?php echo $e_mail; ?>" />
			<span class="tooltip" id="tooltip1">Vous devez saisir une adresse mail tel que @gmail.com; @laposte.net, ...</span></br>
			statut juridique (SARL, SA, ...): <input type="text" name='e_statut' value="<?php echo $e_statut; ?>" /></br>
			Le type de l'entreprise :	<select name="te_code">
				<?php
							$sql="SELECT * FROM type_entreprises;";
							$tab=$connexion->select($sql);
							$max=count($tab);
							for($i=0;$i<$max;$i=$i+1){
							$ligne=$tab[$i];
							echo "<option value='",$ligne['te_code'],"'>",$ligne['te_libelle'],"</option>";
							}
				
				?>
				</select>
			<!--inserer la liste deroulante-->
		<input type="submit" name="envoyer" id="envoyer" value="Envoyer" /></br>
		<input type="reset" name="annuler" id="annuler" value="Annuler" />
	</form>
	<div><?=$message; ?></div>
	<script src="../jquery.js"></script>
        <script>	
			function validForm(){
				var telephone=$('#e_tel');
				var mail=$('#e_mail');
				var reg = new RegExp('^[a-z0-9]+([_|\.|-]{1}[a-z0-9]+)*@[a-z0-9]+([_|\.|-]{1}[a-z0-9]+)*[\.]{1}[a-z]{2,6}$', 'i');
				if (telephone.val().length == 10) {
					$('#tooltip').css('display','none');
                    $('#e_tel').addClass('correct'); 
					
                } else {
					$('#tooltip').css('display','inline-block');
                    $('#e_tel').addClass('incorrect');
					alert("Enregistrement effectué mais votre numero de téléphone est incorrect");
                }
				if (reg.test(mail)) {
					$('#tooltip1').css('display','none');
					$('#e_mail').addClass('correct'); 
				} else {
					$('#tooltip1').css('display','inline-block');
                    $('#e_mail').addClass('incorrect');
					alert("Enregistrement effectué mais votre e-mail est incorrect");
				}
			};
</script>
</body>
</html>