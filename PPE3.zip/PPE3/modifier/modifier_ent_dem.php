<?php
session_start();
$message="";
if (isset($_SESSION['e_code'])) {
			include '../BDD.php';
			$connexion=new BDD('entreprise');
			$e_code = $_SESSION['e_code']; 
    //passage première fois
	if (isset($_GET['id'])){
		$id=$_GET['id'];
		$requete="select * from entreprises_demande where e_code_dem=$id";
		echo $requete;
		$tab=$connexion->select($requete);
		$ligne=$tab[0];
		
		//attributs 
		
			$e_nom_dem=$ligne['e_nom_dem'];
			$e_adresse1_dem=$ligne['e_adresse1_dem'];
			$e_adresse2_dem=$ligne['e_adresse2_dem'];
			$e_ville_dem=$ligne['e_ville_dem'];
			$e_codpostal_dem=$ligne['e_codpostal_dem'];
			$e_nom_correspondant_dem=$ligne['e_nom_correspondant_dem'];
			$e_tel_dem=$ligne['e_tel_dem'];
			$e_mail_dem=$ligne['e_mail_dem'];
			$e_statut_dem=$ligne['e_statut_dem'];
			$te_code_dem=$ligne['te_code_dem'];	
   }
  else {
				$id = $_POST['id'];
						$e_nom_dem=$_POST['e_nom_dem'];
						$e_adresse1_dem=$_POST['e_adresse1_dem'];
						$e_adresse2_dem=$_POST['e_adresse2_dem'];
						$e_ville_dem=$_POST['e_ville_dem'];
						$e_codpostal_dem=$_POST['e_codpostal_dem'];
						$e_nom_correspondant_dem=$_POST['e_nom_correspondant_dem'];
						$e_tel_dem=$_POST['e_tel_dem'];
						$e_mail_dem=$_POST['e_mail_dem'];
						$e_statut_dem=$_POST['e_statut_dem'];
						$te_code_dem=$_POST['te_code_dem'];	
		
					$requete= "UPDATE entreprises_demande SET e_nom_dem='$e_nom_dem', e_adresse1_dem='$e_adresse1_dem', e_adresse2_dem='$e_adresse2_dem',
					e_ville_dem='$e_ville_dem', e_codpostal_dem='$e_codpostal_dem', e_nom_correspondant_dem='$e_nom_correspondant_dem', e_tel_dem='$e_tel_dem', 
					e_statut_dem='$e_statut_dem', e_mail_dem='$e_mail_dem', te_code_dem=$te_code_dem WHERE e_code_dem='$id'";
					 $message=$connexion->insert($requete);
		if($message==''){
			$message='mise à jour bien effectuée';
		}
	}
}
else {
			header("location:../login_ent.php");
		}
?>
<html>
<header>
<?php
include"../page/header.php";


?>
</header>
<body>
<?php
include"../page/nav.php";
?>
<head>
    <meta charset="utf-8">
<title>suivie entreprise</title>
<link rel="stylesheet" href="../CSS/style1.css" />
<style>
			.correct {
				border-color: rgba(68, 191, 68, 0.75);
			}
			.incorrect {
				border-color: rgba(191, 68, 68, 0.75);
			}
			
			.tooltip {
				display:none;
				margin-left: 20px;
				padding: 2px 4px;}
            </style>
</head>

 <h1>Modifier entreprise n°<?php echo $id; ?></h1>
	<form method="post" action="modifier_ent_dem.php"> 
	 <input type='hidden' name='id' value='<?php echo $id; ?>'/>
		
			nom: <input type="text" name='e_nom_dem' value="<?php echo $e_nom_dem; ?>"/></br>
			adresse1: <input type="text" name='e_adresse1_dem' value="<?php echo $e_adresse1_dem;?>" /></br>
			adresse2: <input type="text" name='e_adresse2_dem' value="<?php echo $e_adresse2_dem;?>" /></br>
			ville: <input type="text" name='e_ville_dem' value="<?php echo $e_ville_dem;?>"/></br>
			nom correspondant: <input type="text" name='e_nom_correspondant_dem' value="<?php echo $e_nom_correspondant_dem; ?>" /></br>
			code postal: <input type="text" name='e_codpostal_dem' value="<?php echo $e_codpostal_dem;?>" /></br>
			telephone: <input type="text" name='e_tel_dem' id='e_tel_dem' value="<?php echo $e_tel_dem; ?>" />
			<span class="tooltip" id="tooltip">Vous devez saisir un numéro de téléphone a 10 chiffres</span></br>
			mail: <input type="text" name='e_mail_dem' id='e_mail_dem' value="<?php echo $e_mail_dem; ?>" />
			<span class="tooltip" id="tooltip1">Vous devez saisir une adresse mail tel que @gmail.com; @laposte.net, ...</span></br>
			statut juridique (SARL, SA, ...): <input type="text" name='e_statut_dem' value="<?php echo $e_statut_dem; ?>" /></br>
			Le libelle de l'entreprise :	<select name="te_code_dem">
				<?php
							$sql="SELECT * FROM type_entreprises;";
							$tab=$connexion->select($sql);
							$max=count($tab);
							for($i=0;$i<$max;$i=$i+1){
							$ligne=$tab[$i];
							echo "<option value='",$ligne['te_code'],"'>",$ligne['te_libelle'],"</option>";
							}
				
				?>
				</select>
			<!--inserer la liste deroulante-->
		<input type="submit" name="envoyer" id="envoyer" value="Envoyer" /></br>
		<input type="reset" name="annuler" id="annuler" value="Annuler" />
	</form>
	<div><?=$message; ?></div>
	<script src="../jquery.js"></script>
	<script>	
			function validForm(){
				var telephone=$('#e_tel_dem');
				var mail=$('#e_mail_dem');
				var reg = new RegExp('^[a-z0-9]+([_|\.|-]{1}[a-z0-9]+)*@[a-z0-9]+([_|\.|-]{1}[a-z0-9]+)*[\.]{1}[a-z]{2,6}$', 'i');
				if (telephone.val().length == 10) {
					$('#tooltip').css('display','none');
                    $('#e_tel_dem').addClass('correct'); 
					
                } else {
					$('#tooltip').css('display','inline-block');
                    $('#e_tel_dem').addClass('incorrect');
					alert("Enregistrement effectué mais votre numero de téléphone est incorrect");
                }
				if (reg.test(mail)) {
					$('#tooltip1').css('display','none');
					$('#e_mail_dem').addClass('correct'); 
				} else {
					$('#tooltip1').css('display','inline-block');
                    $('#e_mail_dem').addClass('incorrect');
					alert("Enregistrement effectué mais votre e-mail est incorrect");
				}
			};
</script>
</body>
</html>