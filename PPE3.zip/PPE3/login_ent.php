<?php
session_start();
		$message="";
		$login="";
		$mdp="";
		$categorie="";
		include 'BDD.php';
		
		
		if(isset($_POST['login'])){
			$connexion=new BDD('entreprise');
				$login=$_POST['login'];
				$mdp=$_POST['mdp'];
				//on récupère la variable "catégorie" pour savoir dans quelle table la requete doit chercher
				$categorie=$_POST['categorie'];
				
				//on met la variable $categorie dans le form pour faire la distinction
				$requete="select e_code, login, mdp from $categorie where mdp='$mdp' and login='$login';";
				$tab=$connexion->select($requete);
				//on met en place une vérification quant à la saisie du mdp et du login
				if($tab == null){
					$message= "Mot de passe ou nom de compte incorrectes";
				}
				//les 2 conditions permettent d'envoyer l'utilisateur sur la page 
				//qui correspond à son login, à son mdp et à sa profession
				else if($categorie=="etudiant"){

					$_SESSION['e_code']=$tab[0]["e_code"]; 
					header("location:lister/afficherempV2.php");
				}
				else if($categorie="enseignant") {
					session_start();
					$_SESSION['e_code']=$tab[0]["e_code"]; 
					header("location:lister/afficherempV1.php");
				}
		}
	?>


	<!DOCTYPE html>
<html>
<header>
<?php
include "/page/header.php";
?>
</header>

	<head>
		<meta charset='utf-8' />
		<link rel='stylesheet' href='CSS/style.css' />
		
		<title>Gestion des demandes de travaux</title>
	</head>
		
	<body><div id='cadre'>
	<h1>Gestion des Entreprises</h1>
	
	
	<section>
    <form name="identification" method="POST" action="login_ent.php" >
       
           Login <input name="login" type="text" value="<?php echo $login;?>"  />
      
            Mot de passe <input name="mdp" type="text" value="<?php echo $mdp;?>"/></br>
			Votre profession <select name="categorie">
			
						<option value="enseignant">Enseignant</option>
						<option value="etudiant">Etudiant</option>
			</select>
       
            <input type="submit"/>
			 </form>
      <br>
	  <?php echo $message ?>
   
</section>
	
</body>
</html>