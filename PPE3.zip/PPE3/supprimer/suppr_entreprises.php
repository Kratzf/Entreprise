<?php
session_start();
			$titre="entreprises";
if (isset($_SESSION['e_code'])) {
			include '../BDD.php';
			$connexion=new BDD('entreprise');
			$e_code = $_SESSION['e_code']; 
			if (isset($_GET['e_code'])) {
				$e_code=$_GET['e_code'];
				$sql = "DELETE FROM entreprises WHERE e_code=$e_code";
				$res=$connexion->exec($sql);
				if($res!="") {
					echo $res;
				}else {
					echo "Suppression de l'entreprise ".$e_code." effectue !</br>";
					//header("location:../lister/liste_ent.php");
				}
			}
			else {
				echo "probleme pour récupérer la variable";
			}
}
else {
			header("location:../login_ent.php");
		}
			//die();						
	?>


<html>

<head>
	<title></title>
	<meta charset="utf-8" />
</head>

<body>
	<a href='../lister/liste_ent.php'>Retour vers la page précédente</a>
		
</body>