<!DOCTYPE html>

<html>

<head>
	<title></title>
	<meta charset="utf-8" />
</head>

<body>
	<h2>Suppression des entreprises</h2>
		
	<?php
			$titre="entreprises";
			session_start();
if (isset($_SESSION['e_code'])) {
			include 'BDD.php';
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code']; 
			if (isset($_GET['e_code_dem'])) {
				$e_code_dem=$_GET['e_code_dem'];
				$sql = "DELETE FROM entreprises_demande WHERE e_code_dem=$e_code_dem";
				$res=$connexion->exec($sql);
				if($res!="") {
					echo $res;
				}else {
					echo "Suppression de l'entreprise ".$e_code_dem." effectue !";
				}
			}
			else {
				echo "probleme pour récupérer la variable";
			}
}
else {
			header("location:../login_ent.php");
		}
			//header("location:liste_ent.php");
			die();						
	?>