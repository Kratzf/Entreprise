<!DOCTYPE html>

<html>

<head>
	<title></title>
	<meta charset="utf-8" />
</head>

<body>
	<h2>Suppression des entreprises</h2>
		
	<?php
			$titre="entreprises";
			  session_start();
if (isset($_SESSION['e_code'])) {
			include 'BDD.php';
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code']; 
			if (isset($_GET['e_code'])) {
				$e_code=$_GET['e_code'];
				$sql = "DELETE FROM entreprises WHERE e_code=$e_code";
				$res=$connexion->exec($sql);
				if($res!="") {
					echo $res;
				}else {
					echo "Suppression de l'entreprise ".$e_code." effectue !";
				}
			}
			else {
				echo "probleme pour récupérer la variable";
			}
}
else {
			header("location:../login_ent.php");
		}
			//header("location:liste_ent.php");
			die();						
	?>