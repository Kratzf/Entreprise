<?php
session_start();

	$e_code="";
	$et_nom="";
	$et_prenom="";
	$login="";
	$mdp="";
	$et_mail="";
	$id_utilisateur_et="";
		if (isset($_SESSION['e_code'])) {
			include 'BDD.php';
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
			$requete="select et_nom, et_prenom, login, mdp, et_mail, id_utilisateur_et
					from etudiant
					WHERE e_code=$e_code";
					//echo $requete;
					$tab=$connexion->select($requete);
					$ligne = $tab[0];
						$login=$ligne['login'];
						$mdp=$ligne['mdp'];
						$et_nom=$ligne['et_nom'];
						$et_prenom=$ligne['et_prenom'];
						$id_utilisateur_et=$ligne['id_utilisateur_et'];
						$et_mail=$ligne['et_mail'];
						echo "<section>";
					echo "</br><a href='../creer/creer_ent_dem.php'>Creation entreprises_demandes</a>";
					echo "</br><a href='liste_entV2.php'>Liste des entreprises</a>";
					echo "</br><a href='liste_ent_demV2.php'>Liste des entreprises_demandes</a>";
						echo "</section>";
		}
		else {
			header("location:../login_ent.php");
		}
?>

 <!DOCTYPE html>
<html>
    <head>
		<meta charset="utf-8" />
		<title>Gestion des entreprises</title>
		<link rel="stylesheet" href="../css/style1.css" />
		<!--<link rel="stylesheet" href="../css/style1.css" />-->
	</head>
        
    <body>
		

 <h1>Bienvenue dans l'application de gestion des entreprises</h1>
	<p>
		<span class='label'>Nom </span><span class='champ' name='et_nom'><?php echo $et_nom;?></span><br/>
		<span class='label'> Prénom </span><span class='champ' name='et_prenom'><?php echo $et_prenom;?></span><br /> 
		<span class='label'>Mail </span><span class='champ' name='et_mail'><?php echo $et_mail ?> </span><br/>
		Vous pouvez vous déconnecter:	<a href="deconnexion.php"> DECONNEXION</a>
	</p>
	<br/>
	
 

</body>
