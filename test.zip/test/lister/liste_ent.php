<!DOCTYPE html>

<?php
session_start();
if (isset($_SESSION['e_code'])) {
			include 'BDD.php';
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
$message="";
$requete="select * from entreprises
Inner Join type_entreprises On entreprises.te_code=type_entreprises.te_code;";
$tab = $connexion->select($requete);
$max = count($tab);

?>
<html>
    <head>
        <meta charset="utf-8" />
        <title>PPE suivie entrprise</title>
        <link rel="stylesheet" href="../css/style1.css" />
    </head>
    <body>
	<h1>liste des entreprises</h1>
	<form action="liste_ent.php" method="post">
<?php
$tab=$connexion->select($requete);
//on recup?re la taille du tableau
$max=count($tab);
echo "<table border='1'>";
echo "<th>nom</th><th>adresse 1</th> <th>ville</th> <th>telephone</th><th> mail </th><th> libelle</th><th>Modifier</th> <th>Supprimer</th>";
for($i=0;$i<$max;$i=$i+1){
        $ligne=$tab[$i];
		
        echo "<tr>".
             "<td><a href='detail_entr.php?id=",$ligne['e_code'],"'>",$ligne['e_nom'],"</a></td>".
			 "<td>",$ligne['e_adresse1'],"</td>".
             "<td>",$ligne['e_ville'],"</td>".
			 "<td>",$ligne['e_tel'],"</td>".
			 "<td>",$ligne['e_mail'],"</td>".
			 "<td>",$ligne['te_libelle'],"</td>".
			 "<td> <a href='../modifier/modifier_ent.php?id=",$ligne['e_code'],"'>",$ligne['e_code'],"</a></td>".
			 "<td> <a href='../supprimer/suppr_entreprises.php?e_code=",$ligne['e_code'],"'>",$ligne['e_code'],"</a></td>".
             "</tr>";
}



echo"</table>";
echo $message;
}
else {
			header("location:../login_ent.php");
		}
	?>
	</form>
    </body>
</html>


