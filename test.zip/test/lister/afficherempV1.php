<?php
session_start();

	$e_code="";
	$en_nom="";
	$en_prenom="";
	$login="";
	$mdp="";
	$en_mail="";
	$id_utilisateur_en="";
		if (isset($_SESSION['e_code'])) {
			include 'BDD.php';
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
			$requete="select en_nom, en_prenom, login, mdp, en_mail, id_utilisateur_en
					from enseignant
					WHERE e_code=$e_code";
					//echo $requete;
					$tab=$connexion->select($requete);
					$ligne = $tab[0];
						$login=$ligne['login'];
						$mdp=$ligne['mdp'];
						$en_nom=$ligne['en_nom'];
						$en_prenom=$ligne['en_prenom'];
						$id_utilisateur_en=$ligne['id_utilisateur_en'];
						$en_mail=$ligne['en_mail'];
						echo "<section>";
					echo "</br><a href='../creer/creer_ent.php'>Creation entreprises</a>";
					echo "</br><a href='liste_ent.php'>Liste des entreprises</a>";
					echo "</br><a href='liste_ent_dem.php'>Liste des entreprises_demandes</a>";
						echo "</section>";
		}
		else {
			header("location:../login_ent.php");
		}
?>

 <!DOCTYPE html>
<html>
    <head>
		<meta charset="utf-8" />
		<title>Gestion des entreprises</title>
		<link rel="stylesheet" href="../css/style1.css" />
		<!--<link rel="stylesheet" href="../css/style1.css" />-->
	</head>
        
    <body>
		

 <h1>Bienvenue dans l'application de gestion des entreprises</h1>
	<p>
		<span class='label'>Nom </span><span class='champ' name='en_nom'><?php echo $en_nom;?></span><br/>
		<span class='label'> Prénom </span><span class='champ' name='en_prenom'><?php echo $en_prenom;?></span><br /> 
		<span class='label'>Mail </span><span class='champ' name='en_mail'><?php echo $en_mail ?> </span><br/>
		Vous pouvez vous déconnecter:	<a href="deconnexion.php"> DECONNEXION</a>
	</p>
	<br/>
	
 

</body>
