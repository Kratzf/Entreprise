
	<?php
		$message="";
		$login="";
		$mdp="";
		$categorie="";
		include 'BDD.php';
		
		
		if(isset($_POST['login'])){
			$connexion=new BDD('suivieent');
				$login=$_POST['login'];
				$mdp=$_POST['mdp'];
				$categorie=$_POST['categorie'];
				
				$requete="select e_code, login, mdp from $categorie where mdp='$mdp' and login='$login';";
				$tab=$connexion->select($requete);
				if($tab == null){
					$message= "Mot de passe ou nom de compte incorrectes";
				}
				else if($categorie=="etudiant"){
					session_start();
					$_SESSION['e_code']=$tab[0]["e_code"]; 
					header("location:lister/afficherempV2.php");
				}
				else if($categorie="enseignant") {
					session_start();
					$_SESSION['e_code']=$tab[0]["e_code"]; 
					//$message="vous avez le matricule $e_matricule";
					header("location:lister/afficherempV1.php");
				}
		}
	?>


	<!DOCTYPE html>
<html>

	<head>
		<meta charset='utf-8' />
		<link rel='stylesheet' href='./css/style.css' />
		
		<title>Gestion des entreprises</title>
			<!--[if lte IE 6]><style type='text/css'>#corps { height: 100%; /* min-height */ }</style><![endif]-->
	</head>
		
	<body><div id='cadre'>
	<header>
	<h1>Gestion des entreprises</h1>
	</header>
	
	
	<section>
    <form name="identification" method="POST" action="login_ent.php" >
       
           Login <input name="login" type="text" value="<?php echo $login;?>"  />
      
            Mot de passe <input name="mdp" type="text" value="<?php echo $mdp;?>"/></br>
			Votre profession <select name="categorie">
			
						<option value="enseignant">Enseignant</option>
						<option value="etudiant">Etudiant</option>
			</select>
       
            <input type="submit"/>
			 </form>
      <br>
	  <?php echo $message ?>
   
</section>
	
</body>
</html>