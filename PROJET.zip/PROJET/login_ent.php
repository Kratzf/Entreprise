<?php
session_start();
		$message="";
		$login="";
		$mdp="";
		$categorie="";
		include 'BDD.php';
		
		
		if(isset($_POST['login'])){
			$connexion=new BDD('entreprise');
				$login=$_POST['login'];
				$mdp=$_POST['mdp'];
				$categorie=$_POST['categorie'];
				
				$requete="select e_code, login, mdp from $categorie where mdp='$mdp' and login='$login';";
				$tab=$connexion->select($requete);
				if($tab == null){
					$message= "Mot de passe ou nom de compte incorrectes";
				}
				else if($categorie=="etudiant"){

					$_SESSION['e_code']=$tab[0]["e_code"]; 
					header("location:lister/afficherempV2.php");
				}
				else if($categorie="enseignant") {
					session_start();
					$_SESSION['e_code']=$tab[0]["e_code"]; 
					//$message="vous avez le matricule $e_matricule";
					header("location:lister/afficherempV1.php");
				}
		}
	?>


	<!DOCTYPE html>
<html>
<header>
<?php
include "/page/header.php";
?>
</header>

	<head>
		<meta charset='utf-8' />
		<link rel='stylesheet' href='CSS/style.css' />
		
		<title>Gestion des demandes de travaux</title>
			<!--[if lte IE 6]><style type='text/css'>#corps { height: 100%; /* min-height */ }</style><![endif]-->
	</head>
		
	<body><div id='cadre'>
	<h1>Gestion des Entreprises</h1>
	
	
	<section>
    <form name="identification" method="POST" action="login_ent.php" >
       
           Login <input name="login" type="text" value="<?php echo $login;?>"  />
      
            Mot de passe <input name="mdp" type="text" value="<?php echo $mdp;?>"/></br>
			Votre profession <select name="categorie">
			
						<option value="enseignant">Enseignant</option>
						<option value="etudiant">Etudiant</option>
			</select>
       
            <input type="submit"/>
			 </form>
      <br>
	  <?php echo $message ?>
   
</section>
	
</body>
</html>