<!DOCTYPE html>
<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<?php
//utilisation du session_start pour pallier a toute tentative d'intrusion
session_start();
if (isset($_SESSION['e_code'])) {
			include 'affcreer.php';
			//creer_entr();
}
else {
			header("location:../index.php");
		}
	?>
<html>
<head>
	<meta charset="utf-8" />
	<title>suivie entreprise</title>
	<style>
			.correct {
				border-color: rgba(68, 191, 68, 0.75);
			}
			.incorrect {
				border-color: rgba(191, 68, 68, 0.75);
			}
			
			.tooltip {
				display:none;
				margin-left: 20px;
				padding: 2px 4px;}
            </style>
			<link rel="stylesheet" href="../css/style1.css" />
</head>
<body>
<header></header>
	<section>
	<h1>creer entreprise</h1>
	<form method="post" action="creer_ent.php"> 
		
			nom: <input type="text" name='e_nom' id="nom" value="<?php echo $e_nom; ?>"/>
			<span class="error-message"></span></br>
			
			adresse1: <input type="text" name='e_adresse1' id="adresse1" value="<?php echo $e_adresse1; ?>" />
			<span class="error-message"></span></br>
			
			adresse2: <input type="text" name='e_adresse2' id="adresse2" value="<?php echo $e_adresse2; ?>"/>
			<span class="error-message"></span></br>
			
			ville: <input type="text" name='e_ville' id="ville" value="<?php echo $e_ville; ?>" />
			<span class="error-message"></span></br>
			
			code postal: <input type="text" name='e_codPostal' id="CP" value="<?php echo $e_codPostal; ?>" />
			<span class="error-message"></span></br>
			
			nom correspondant: <input type="text" name='e_nom_correspondant' id="nom_correspondant" value="<?php echo $e_nom_correspondant; ?>" />
			<span class="error-message"></span></br>
			
			telephone: <input type="text" name='e_tel' id='tel' value="<?php echo $e_tel; ?>" />
			<span class="error-message"></span></br>
			
			mail: <input type="email" name='e_mail' id='mail' value="<?php echo $e_mail; ?>" /></br>
			
			statut juridique (SARL, SA, ...): <input type="text" name='e_statut' value="<?php echo $e_statut; ?>" /></br>
			Le type de l'entreprise :	<select name="te_code">
			<?php
						$sql="SELECT * FROM type_entreprises;";
						$tab=$connexion->select($sql);
						$max=count($tab);
						for($i=0;$i<$max;$i=$i+1){
						$ligne=$tab[$i];
						echo "<option value='",$ligne['te_code'],"'>",$ligne['te_libelle'],"</option>";
						}
			
			?>
			</select></br>
			<!--inserer la liste deroulante-->
		<input type="submit" name="envoyer" id="envoyer" value="Envoyer" onclick="validForm();"/></br>
		<input type="reset" name="annuler" id="annuler" />
	</form>
	</section>
	<script src="../jquery.js"></script>
         <script src="../app.js"></script>
</body>
</html>
