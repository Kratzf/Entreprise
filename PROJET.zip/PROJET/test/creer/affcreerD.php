<?php
include 'BDD.php';
	$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
		$e_nom_dem="";
		$e_adresse1_dem="";
		$e_adresse2_dem="";
		$e_ville_dem="";
		$e_codPostal_dem="";
		$e_nom_correspondant_dem="";
		$e_tel_dem="";
		$e_mail_dem="";
		$e_statut_dem="";
		
		$message="";
		
	if(isset($_POST['e_nom_dem'])){
		$e_nom_dem=$_POST['e_nom_dem'];
		$e_adresse1_dem=$_POST['e_adresse1_dem'];
		$e_adresse2_dem=$_POST['e_adresse2_dem'];
		$e_ville_dem=$_POST['e_ville_dem'];
		$e_codPostal_dem=$_POST['e_codPostal_dem'];
		$e_nom_correspondant_dem=$_POST['e_nom_correspondant_dem'];
		$e_tel_dem=$_POST['e_tel_dem'];
		$e_mail_dem=$_POST['e_mail_dem'];
		$e_statut_dem=$_POST['e_statut_dem'];
		$te_code_dem=$_POST['te_code_dem'];	
		//tests du formulaire
		
			if ($message==""){
				//preparation de la requete
					$requete="insert into entreprises_demande (e_nom_dem ,e_adresse1_dem ,e_adresse2_dem ,e_ville_dem ,e_codPostal_dem, 
					e_nom_correspondant_dem,e_tel_dem ,e_mail_dem, e_statut_dem, te_code_dem) 
					values('$e_nom_dem','$e_adresse1_dem' ,'$e_adresse2_dem' ,'$e_ville_dem' ,'$e_codPostal_dem', 
					'$e_nom_correspondant_dem' ,'$e_tel_dem' ,'$e_mail_dem','$e_statut_dem', $te_code_dem)";
					echo $requete;
					$resultats = $connexion->insert($requete);
				//execution de la requete
				if($resultats=="") {
						echo "</br>Enregistrement de l'entreprise ".$e_nom_dem." effectué !";
					}
					else {
						echo $resultats;
					}
				
				
			}
			return $resultats;
	}


?>