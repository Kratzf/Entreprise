<?php
include 'BDD.php';

//function creer_entr() {
			//connexion
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
			
			$e_nom="";
		$e_adresse1="";
		$e_adresse2="";
		$e_ville="";
		$e_codPostal="";
		$e_nom_correspondant="";
		$e_tel="";
		$e_mail="";
		$e_statut="";
		
		$message="";
		
	if(isset($_POST['e_nom'])){
		$e_nom=$_POST['e_nom'];
		$e_adresse1=$_POST['e_adresse1'];
		$e_adresse2=$_POST['e_adresse2'];
		$e_ville=$_POST['e_ville'];
		$e_codPostal=$_POST['e_codPostal'];
		$e_nom_correspondant=$_POST['e_nom_correspondant'];
		$e_tel=$_POST['e_tel'];
		$e_mail=$_POST['e_mail'];
		$e_statut=$_POST['e_statut'];
		$te_code=$_POST['te_code'];	
		//tests du formulaire
		
			if ($e_nom !='' && $e_adresse1 !='' && $e_ville !='' && $e_codPostal !='' && 
				$e_nom_correspondant !='' && $e_tel !='' && $e_mail !='' && $e_statut !=''){
				//insertion d'une ligne dans la table vitesse les donnees sont valides
				//connexion
				//preparation de la requete
					$requete="insert into entreprises (e_nom ,e_adresse1 ,e_adresse2 ,e_ville ,e_codPostal, e_nom_correspondant,e_tel ,e_mail, e_statut,te_code) 
					values('$e_nom','$e_adresse1' ,'$e_adresse2' ,'$e_ville' ,'$e_codPostal', '$e_nom_correspondant' ,'$e_tel' ,'$e_mail','$e_statut',$te_code)";
					echo $requete;
					//execution de la requete
					$resultats = $connexion->insert($requete);
				
				if($resultats=="") {
						//echo "</br>Enregistrement de l'entreprise ".$e_nom." effectué !";
						$message = "Erreur de saisie";
					}
					else {
						echo $resultats;
					}
				
				
			}
			else {
				echo "Il manque des infos";
			}
			return $resultats;
	}
//}


?>