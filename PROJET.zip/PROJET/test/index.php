<?php
	require("login.php");
?>

	<!DOCTYPE html>
<html>

	<head>
		<meta charset='utf-8' />
		<link rel='stylesheet' href='./css/style1.css' />
		
		<title>Gestion des entreprises</title>
			<!--[if lte IE 6]><style type='text/css'>#corps { height: 100%; /* min-height */ }</style><![endif]-->
	</head>
		
	<body><div id='cadre'>
	<header>
	</header>
	
	<section>
    <form name="identification" method="POST" action="index.php" >
       
           Login <input name="login" type="text" value="<?php echo $login;?>"  />
      
            Mot de passe <input name="mdp" type="text" value="<?php echo $mdp;?>"/></br>
			Votre profession <select name="categorie">
			
						<option value="enseignant">Enseignant</option>
						<option value="etudiant">Etudiant</option>
			</select>
       
            <input type="submit"/>
			 </form>
      <br>
	  <?php echo $message ?>
   
</section>
	
</body>
</html>