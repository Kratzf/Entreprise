<?php

include('include/BDD.php');

class RequeteLister extends BDD {

	function getAcc() {
		$connexion=$this->getConnexion('suivieent');
		
	} 

	function getAffch1($login,$mdp,$categorie) {
		$connexion = $this->getConnexion('suivieent');
				$requete="select en_nom, en_prenom, login, mdp, en_mail, id_utilisateur_en
					from $categorie
					WHERE mdp='$mdp' and login='$login'";
				$tab=$this->select($requete);
				if($tab == null){
					$message= "Mot de passe ou nom de compte incorrectes";
				}
	}
	
	function getsuppDT($dt_numero) {
		$connexion = $this->getConnexion('gestiondt');
		if (isset($_GET['id'])) {
				$dt_numero=$_GET['id'];
				$sql = "DELETE FROM demande_de_travaux WHERE dt_numero=$dt_numero";
				$res=$connexion->exec($sql);
				if($res!="") {
					echo "Pb en vue";
				}else {
					echo "Suppression de l'entreprise ".$dt_numero." effectue !</br>";
					//header("location:index.php");
				}
			}
			else {
			//	echo "probleme pour récupérer la variable";
			}	
	}
}
?>