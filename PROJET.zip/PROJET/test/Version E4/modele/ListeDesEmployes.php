<?php

/*
	Gestion de la logique des données: requêtes et accès avec PDO
*/

include_once('include/BDD.php');

class ListeDesEmployes extends BDD {

	function getEmp() {
		$connexion=$this->getConnexion('gestiondt');
		$message="";
		$requete="select e_matricule, e_nom, e_prenom, f_libelle
		from employe, fonction
		where employe.f_code=fonction.f_code
		order by e_matricule";
		$tab_emp=$this->select($requete);
		return $tab_emp;
	}
	
	function getDetailEmp($e_matricule) {
		$connexion = $this->getConnexion('gestiondt');
		$id = $_GET['id'];
		$requete = "select employe.*
		from employe
		where e_matricule=$e_matricule";
		$param=array('e_matricule'=>$e_matricule );
		$tab= $this->prepare_select($requete, $param);
		if(count($tab)==1) {
			$ligne=$tab[0];
			return $tab[0];
		}
		else {
			throw new Exception("Aucune demande de travaux ne correspond à l'identifiant $e_matricule");
		}
	}
}
?>