<?php

/*
	Gestion de la logique des données: requêtes et accès avec PDO
*/

include('include/BDD.php');

function getDT() {
	$connexion=new BDD('gestiondt');
	$message="";
	$requete="select dt_numero,td_libelle,dt_datedemande,dt_motif
   from demande_de_travaux d,type_de_demande t
   where d.td_code=t.td_code 
   order by dt_numero desc";
  $tab_DT=$connexion->select($requete);
  return $tab_DT;
} 

function getDetailDT($dt_numero) {
	$connexion = new BDD('gestiondt');
            $id = $_GET['id'];
            $requete = "select demande_de_travaux.*,  ee.e_nom
	from demande_de_travaux inner join employe ee 
	on demande_de_travaux.e_matricule_emettre=ee.e_matricule
	where dt_numero=$dt_numero";
	$param=array('dt_numero'=>$dt_numero );
	$tab= $connexion->prepare_select($requete, $param);
	if(count($tab)==1) {
		$ligne=$tab[0];
		return $tab[0];
	}
	else {
		throw new Exception("Aucune demande de travaux ne correspond à l'identifiant $dt_numero");
	}
}

function getEmp() {
	$connexion=new BDD('gestiondt');
	$message="";
	$requete="select e_matricule, e_nom, e_prenom, f_libelle
	from employe, fonction
	where employe.f_code=fonction.f_code
	order by e_matricule";
	$tab_emp=$connexion->select($requete);
	return $tab_emp;
}
?>