<!DOCTYPE html>
<html>
	<head>
		<meta charset='utf-8' />
		<link rel='stylesheet' href='./css/style.css' />
		
		<title>Gestion des demandes de travaux</title>
		<link rel='stylesheet' type='text/css' href='style/styles.css'/>
			<!--[if lte IE 6]><style type='text/css'>#corps { height: 100%; /* min-height */ }</style><![endif]-->
	</head>
		
	<body><div id='cadre'><header>
		<h1><?= $this->titre ?></h1></header>
		<table><tr>
			<td><a href="index.php?listerDT"> Liste des DT</a></td>
			<td><a href="index.php?menu=listeremp"> Liste des employe</a></td>
		</tr></table>
<section>
	<?= $contenu ?>
 

<!--<h3><?=$message?></h3>"-->
</section>
<footer><h4>Lycée Merleau Ponty website &copy; - BTS SIO Rochefort</br>contact courriel : sio17@orange.fr</h4></footer>
</div></body>
</html>