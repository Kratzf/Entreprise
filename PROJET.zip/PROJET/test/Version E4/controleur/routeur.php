<?php
require_once('controleur/controleur.php');

class Routeur{
	private $ctrl;
	public function __construct() {
		$this->ctrl=new Controleur();
	}
	public function routerRequete(){
 
		 try {
			 if(isset($_GET['action'])) {
				 //si action -detailDT on appelle la fonction detailDT du controleur
				 if($_GET['action']=='detailDT') {
					 
					 if(isset($_GET['id'])) {
						 //on vérifie le type de l'id d'une demande de travaux
						 $id=intval($_GET['id']);
						 if($id!=0) {
							 $this->ctrl->detailDT($id);
						 }
						 else {
							 throw new Exception("Identifiant de demande de travaux incorrecte");
						 }
					 }
					 else {
						 throw new Exception("Aucun identifiant de demande de travaux");
					 }
				 }
			 }
			 
			 else if(isset($_GET['acc1'])) {
				  if($_GET['acc1']=='afficherempV1') {
					  $this->ctrl->afficheR1();
			 }
			 else {
						 throw new Exception("Action incorrecte");
					 }
			}
		 
			else if(isset($_GET['defemp'])) {
				if($_GET['defemp']=='detailEmp') {
					if(isset($_GET['id'])) {
						 //on vérifie le type de l'id d'une demande de travaux
						 $id=intval($_GET['id']);
						 if($id!=0) {
							 $this->ctrl->detailEmp($id);
						 }
						 else {
							 throw new Exception("Identifiant de demande de travaux incorrecte");
						 }
					 }
					 else {
						 throw new Exception("Aucun identifiant de demande de travaux");
					 }
				 }
				}
				else if(isset($_GET['supp'])) {
					if($_GET['supp']=='suppDT') {
					if(isset($_GET['id'])) {
						 //on vérifie le type de l'id d'une demande de travaux
						 $id=intval($_GET['id']);
						 if($id!=0) {
							 $this->ctrl->suppDT($id);
						 }
						 else {
							 throw new Exception("Identifiant de demande de travaux incorrecte");
						 }
					 }
					 else {
						 throw new Exception("Aucun identifiant de demande de travaux");
					 }
				 }
				}
				
				else {
				 $this->ctrl->Accueil();
			 }
			}
			 catch (Exception $e) {
			 $this->ctrl->erreur($e->getMessage());
		  }
			 
		 }
		
 }

?>