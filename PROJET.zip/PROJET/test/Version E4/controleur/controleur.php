<?php
require 'modele/RequeteLister.php';
require 'modele/ListeDesEmployes.php';
require 'vue/Vue.php';

class Controleur {
	private $requetelister;
	private $listeDesEmployes;
//affiche la liste des demandes de travaux
	function Accueil() {
		$vue= new Vue('Accueil');
		$this->requetelister=new RequeteLister();
		$tab=$this->requetelister->getAcc();
		$vue->generer(array('tab'=>$tab));
	}

	//affiche la liste des employes
	function afficheR1($login,$mdp,$categorie) {
		$this->requetelister=new RequeteLister();
		$detailProf=$this->demandeDeTravaux->getDetailDT($login,$mdp,$categorie);
		$vue= new Vue('Afficheremp1');
		$vue->generer(array('detailProf'=>$detailProf));
	}

	//afficher la vueErreur
	function erreur($msgErreur) {
		$vue= new Vue('Erreur');
		$vue->generer(array('msgErreur'=>$msgErreur));
	}
}
?>