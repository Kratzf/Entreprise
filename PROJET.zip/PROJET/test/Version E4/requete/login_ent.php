<?php
		/*$message="";
		$login="";
		$mdp="";
		$categorie="";*/
		//include 'include/BDD.php';
		
		
		if(isset($_POST['login'])){
			$foo=false;
			$connexion=new BDD('suivieent');
				$login=$_POST['login'];
				$mdp=$_POST['mdp'];
				$categorie=$_POST['categorie'];
				
				$requete="select e_code, login, mdp from $categorie where mdp='$mdp' and login='$login';";
				$tab=$connexion->select($requete);
				if($tab == null){
					$message= "Mot de passe ou nom de compte incorrectes";
					$foo=false;
				}
				else if($categorie="enseignant") {
					//session_start();
					//$_SESSION['e_code']=$tab[0]["e_code"]; 
					$foo=true;
				}
				else if($categorie=="etudiant"){
					//session_start();
					//$_SESSION['e_code']=$tab[0]["e_code"]; 
					$foo=true;
				}
				return $foo;
		}
	?>