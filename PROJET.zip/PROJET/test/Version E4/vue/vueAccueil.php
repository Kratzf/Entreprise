<?php $this->titre='Page d accueil'; 
include ('requete/login_ent.php');
ob_start(); ?>
  <header>
	<h1>Gestion des entreprises</h1>
	</header>
	
	<section>
	  
	  <form name="identification" method="POST" action="index.php" >
       
           Login <input name="login" type="text" value="<?php //echo $login;?>"  />
      
            Mot de passe <input name="mdp" type="text" value="<?php //echo $mdp;?>"/></br>
			Votre profession <select name="categorie">
			
						<option value="enseignant">Enseignant</option>
						<option value="etudiant">Etudiant</option>
			</select>
       
            <input type="submit"/>
			 </form>
   
</section>
<?php $contenu=ob_get_clean();?>
<?php require 'gabarit.php' ?>