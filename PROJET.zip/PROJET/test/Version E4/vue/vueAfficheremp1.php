<?php $this->titre='Bienvenue professeur'; 
ob_start(); 
?>
  <h1>Bienvenue dans l'application de gestion des entreprises</h1>
	<p>
		<span class='label'>Nom </span><span class='champ' name='en_nom'><?php echo $en_nom;?></span><br/>
		<span class='label'> Prénom </span><span class='champ' name='en_prenom'><?php echo $en_prenom;?></span><br /> 
		<span class='label'>Mail </span><span class='champ' name='en_mail'><?php echo $en_mail ?> </span><br/>
		Vous pouvez vous déconnecter:	<a href="deconnexion.php"> DECONNEXION</a>
	</p>
	<ul>
                <li>Nom : <?php echo $affichR1['en_nom']; ?></li>
                <li>Prénom: <?php echo $affichR1['en_prenom']; ?></li>
                <li>Mail: <?php echo $affichR1['en_mail']; ?></li>

            </ul>
<?php $contenu=ob_get_clean();?>
<?php require 'gabarit.php' ?>