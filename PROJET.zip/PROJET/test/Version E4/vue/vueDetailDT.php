 <?php
 $this->titre="Liste des demandes de travaux";
 ob_start();
 //datedemande
            ?>
			

            <h1>Demande de travaux <?php $detailDT['dt_numero']; ?></h1>
            <ul>
                <li>employé emetteur : <?php echo $detailDT['e_matricule_emettre']; ?></li>
                <li>date de demande: <?php echo $detailDT['dt_datedemande']; ?></li>
                <li>date de prise en charge: <?php echo $detailDT['dt_date_prise_encharge']; ?></li>
                <li>date d'affectation: <?php echo $detailDT['dt_date_affectation']; ?></li>
                <li>date de cloture: <?php echo $detailDT['dt_date_cloture']; ?></li>
                <li>motif: <?php echo $detailDT['dt_motif']; ?></li>

            </ul>
            <?php $contenu=ob_get_clean();
			require 'gabarit.php'; ?>