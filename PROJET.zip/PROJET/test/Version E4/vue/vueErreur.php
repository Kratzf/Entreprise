<?php $this->titre='Liste des demandes de travaux'; 
ob_start(); ?>
 <p> Une erreur est survenue <?= $msgErreur ?></p>
<?php $contenu=ob_get_clean();?>
<?php require 'gabarit.php' ?>