<?php
 $this->titre="Liste des employés";
 ob_start();
 //datedemande
            ?>
			

            <h1>Matricule de l'employe <?php $detailEmp['e_matricule']; ?></h1>
            <ul>
                <li>Login: <?php echo $detailEmp['e_login']; ?></li>
                <li>Mdp: <?php echo $detailEmp['e_mdp']; ?></li>
                <li>Numéro de service: <?php echo $detailEmp['s_numero']; ?></li>
                <li>Code fonction: <?php echo $detailEmp['f_code']; ?></li>
                <li>Nom: <?php echo $detailEmp['e_nom']; ?></li>
                <li>Prenom: <?php echo $detailEmp['e_prenom']; ?></li>
				<li>Accès: <?php echo $detailEmp['e_acces']; ?></li>

            </ul>
            <?php $contenu=ob_get_clean();
			require 'gabarit.php'; ?>