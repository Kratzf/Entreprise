 <?php
 $this->titre="Liste des demandes de travaux";
 ob_start();
 //datedemande
            ?>
			

            <h1>Demande de travaux <?php $suppDT['dt_numero']; ?> supprimée !</h1>
            
            <?php $contenu=ob_get_clean();
			require 'gabarit.php'; ?>