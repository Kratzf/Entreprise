<?php
 require 'controleur/routeur.php';
 $routeur=new Routeur();
 $routeur->routerRequete();
?>