<!DOCTYPE html>

<html>

<head>
	<title></title>
	<meta charset="utf-8" />
</head>

<body>
	<h2>Suppression des entreprises</h2>
		
	<?php
			$titre="entreprises";
			  session_start();
if (isset($_SESSION['e_code'])) {
			include 'BDD.php';
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code']; 
			if (isset($_GET['e_code'])) {
				$e_code=$_GET['e_code'];
				$sql = "DELETE FROM entreprises WHERE e_code=$e_code";
				$res=$connexion->exec($sql);
				if($res!="") {
					echo $res;
				}else {
					echo "Suppression de l'entreprise ".$e_code." effectue !";
					header("location:../lister/liste_ent.php?acc=list_ens");
				}
			}
			else {
				echo "probleme pour récupérer la variable";
			}
}
else {
			header("location:../index.php");
		}
			die();						
	?>