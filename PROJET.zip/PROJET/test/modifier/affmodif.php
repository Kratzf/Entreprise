<?php
	include 'BDD.php';
	
		$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code']; 
    //passage première fois
		if (isset($_GET['id'])){
			$id=$_GET['id'];
			$requete="select * from entreprises where e_code=$id";
			//echo $requete;
			$tab=$connexion->select($requete);
			$ligne=$tab[0];
			
			//attributs 
			
				$e_nom=$ligne['e_nom'];
				$e_adresse1=$ligne['e_adresse1'];
				$e_adresse2=$ligne['e_adresse2'];
				$e_ville=$ligne['e_ville'];
				$e_codpostal=$ligne['e_codpostal'];
				$e_nom_correspondant=$ligne['e_nom_correspondant'];
				$e_tel=$ligne['e_tel'];
				$e_mail=$ligne['e_mail'];
				$e_statut=$ligne['e_statut'];
				$te_code=$ligne['te_code'];	
	   }
	  else {
					$id = $_POST['id'];
							$e_nom=$_POST['e_nom'];
							$e_adresse1=$_POST['e_adresse1'];
							$e_adresse2=$_POST['e_adresse2'];
							$e_ville=$_POST['e_ville'];
							$e_codpostal=$_POST['e_codpostal'];
							$e_nom_correspondant=$_POST['e_nom_correspondant'];
							$e_tel=$_POST['e_tel'];
							$e_mail=$_POST['e_mail'];
							$e_statut=$_POST['e_statut'];
							$te_code=$_POST['te_code'];	
			
						$requete= "UPDATE entreprises SET e_nom='$e_nom', e_adresse1='$e_adresse1', e_adresse2='$e_adresse2',
						e_ville='$e_ville', e_codpostal='$e_codpostal', e_nom_correspondant='$e_nom_correspondant', e_tel='$e_tel', 
						e_statut='$e_statut', e_mail='$e_mail', te_code=$te_code WHERE e_code='$id'";
						 $message=$connexion->insert($requete);
			if($message==''){
				$message='mise à jour bien effectuée';
			}
		}
	
	
		
?>