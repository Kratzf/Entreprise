<?php
include'BDD.php';

$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code']; 
		//passage première fois
		if (isset($_GET['id'])){
			$id=$_GET['id'];
			$requete="select * from entreprises_demande where e_code_dem=$id";
			//echo $requete;
			$tab=$connexion->select($requete);
			$ligne=$tab[0];
			
			//attributs 
			
				$e_nom_dem=$ligne['e_nom_dem'];
				$e_adresse1_dem=$ligne['e_adresse1_dem'];
				$e_adresse2_dem=$ligne['e_adresse2_dem'];
				$e_ville_dem=$ligne['e_ville_dem'];
				$e_codpostal_dem=$ligne['e_codpostal_dem'];
				$e_nom_correspondant_dem=$ligne['e_nom_correspondant_dem'];
				$e_tel_dem=$ligne['e_tel_dem'];
				$e_mail_dem=$ligne['e_mail_dem'];
				$e_statut_dem=$ligne['e_statut_dem'];
				$te_code_dem=$ligne['te_code_dem'];	
	   }
	  else {
					$id = $_POST['id'];
							$e_nom_dem=$_POST['e_nom_dem'];
							$e_adresse1_dem=$_POST['e_adresse1_dem'];
							$e_adresse2_dem=$_POST['e_adresse2_dem'];
							$e_ville_dem=$_POST['e_ville_dem'];
							$e_codpostal_dem=$_POST['e_codpostal_dem'];
							$e_nom_correspondant_dem=$_POST['e_nom_correspondant_dem'];
							$e_tel_dem=$_POST['e_tel_dem'];
							$e_mail_dem=$_POST['e_mail_dem'];
							$e_statut_dem=$_POST['e_statut_dem'];
							$te_code_dem=$_POST['te_code_dem'];	
			
						$requete= "UPDATE entreprises_demande SET e_nom_dem='$e_nom_dem', e_adresse1_dem='$e_adresse1_dem', e_adresse2_dem='$e_adresse2_dem',
						e_ville_dem='$e_ville_dem', e_codpostal_dem='$e_codpostal_dem', e_nom_correspondant_dem='$e_nom_correspondant_dem', e_tel_dem='$e_tel_dem', 
						e_statut_dem='$e_statut_dem', e_mail_dem='$e_mail_dem', te_code_dem=$te_code_dem WHERE e_code_dem='$id'";
						 $message=$connexion->insert($requete);
			if($message==''){
				$message='mise à jour bien effectuée';
			}
		}

?>