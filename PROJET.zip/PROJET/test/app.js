$(function(){
		$("#envoyer").click(function(){
			var valid=true;
			var reg = new RegExp("^0[1-9]([-. ]?[0-9]{2}){4}$");
			if($('#nom').val()=="") {
				$('#nom').next(".error-message").fadeIn().text("Veuillez entrez votre nom");
				valid=false;
			}
			else if(!$("#nom").val().match(/^[a-z]+$/i)){
				$('#nom').next(".error-message").fadeIn().text("Veuillez entrez un nom valide");
				valid=false;
			}
			else{
				$('#nom').next(".error-message").fadeOut();
			}
			
			if($('#adresse1').val()=="") {
				$('#adresse1').next(".error-message").fadeIn().text("Veuillez entrez votre prenom");
				valid=false;
			}
			else{
				$('#adresse1').next(".error-message").fadeOut();
			}
			
			if($('#adresse2').val()=="") {
				$('#adresse2').next(".error-message").fadeIn().text("Veuillez entrez votre adresse");
				valid=false;
			}
			else{
				$('#adresse2').next(".error-message").fadeOut();
			}
			
			if($('#ville').val()=="") {
				$('#ville').next(".error-message").fadeIn().text("Veuillez entrez votre ville");
				valid=false;
			}
			else{
				$('#ville').next(".error-message").fadeOut();
			}
			
			if($('#tel').val()=="") {
				$('#tel').next(".error-message").fadeIn().text("Veuillez entrez votre numero");
				valid=false;
			}
			else if(!$("#tel").val().match(reg)) {
				$('#tel').next(".error-message").fadeIn().text("Veuillez entrez un numero valide ou complet");
				valid=false;
			}
			else{
				$('#tel').next(".error-message").fadeOut();
			}
			if($('#CP').val()=="") {
				$('#CP').next(".error-message").fadeIn().text("Veuillez entrez votre ville");
				valid=false;
			}
			else{
				$('#CP').next(".error-message").fadeOut();
			}
			if($('#nom_correspondant').val()=="") {
				$('#nom_correspondant').next(".error-message").fadeIn().text("Veuillez entrez votre ville");
				valid=false;
			}
			else{
				$('#nom_correspondant').next(".error-message").fadeOut();
			}
			if($('#statut').val()=="") {
				$('#statut').next(".error-message").fadeIn().text("Veuillez entrez un statut");
				valid=false;
			}
			else{
				$('#statut').next(".error-message").fadeOut();
			}
			
			return valid;
		});
	});