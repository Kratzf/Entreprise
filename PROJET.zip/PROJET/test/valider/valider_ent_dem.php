<html>
<head>
    <meta charset="utf-8">
<title>suivie entreprise</title>
<link rel="stylesheet" href="../css/style1.css" />
</head>
<?php
    $message="";
   
			include 'BDD.php';
			$connexion=new BDD('suivieent');
			
    //passage première fois
	if (isset($_GET['e_code_dem'])){
		$e_code_dem=$_GET['e_code_dem'];
		$requete="select * from entreprises_demande where e_code_dem=$e_code_dem";
		echo $requete;
		$tab=$connexion->select($requete);
		$ligne=$tab[0];
		
		//attributs 
		
			$e_nom_dem=$ligne['e_nom_dem'];
			$e_adresse1_dem=$ligne['e_adresse1_dem'];
			$e_adresse2_dem=$ligne['e_adresse2_dem'];
			$e_ville_dem=$ligne['e_ville_dem'];
			$e_codpostal_dem=$ligne['e_codpostal_dem'];
			$e_nom_correspondant_dem=$ligne['e_nom_correspondant_dem'];
			$e_tel_dem=$ligne['e_tel_dem'];
			$e_mail_dem=$ligne['e_mail_dem'];
			$e_statut_dem=$ligne['e_statut_dem'];
			$te_code_dem=$ligne['te_code_dem'];	
			
			
					$requete= "insert into entreprises (e_nom ,e_adresse1 ,e_adresse2 ,e_ville ,e_codPostal, 
					e_nom_correspondant,e_tel ,e_mail, e_statut,te_code) 
					SELECT e_nom_dem ,e_adresse1_dem ,e_adresse2_dem ,e_ville_dem ,e_codpostal_dem, 
					e_nom_correspondant_dem,e_tel_dem ,e_mail_dem, e_statut_dem, te_code_dem
					FROM entreprises_demande Inner Join type_entreprises On entreprises_demande.te_code_dem=type_entreprises.te_code
					WHERE e_nom_dem ='$e_nom_dem' and e_adresse1_dem='$e_adresse1_dem' and e_adresse2_dem='$e_adresse2_dem' and
					e_ville_dem='$e_ville_dem' and e_codpostal_dem='$e_codpostal_dem' and e_nom_correspondant_dem='$e_nom_correspondant_dem'
					and e_tel_dem='$e_tel_dem' and e_mail_dem='$e_mail_dem' and e_statut_dem='$e_statut_dem' and
					te_code_dem=$te_code_dem";
					 $message=$connexion->insert($requete);
					 //echo $requete;
					 if($message==''){
						$message=$message.'Validation réussie';
						$sql = "DELETE FROM entreprises_demande WHERE e_nom_dem='$e_nom_dem'";
							$res=$connexion->exec($sql);
							header("location:../lister/liste_ent_dem.php?accdem=list_ens");
					}
   }
	
?>