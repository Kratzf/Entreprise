<?php
		$message="";
		$login="";
		$mdp="";
		include 'BDD.php';
		
		
		if(isset($_POST['login'])&& isset($_POST['mdp'])){
			$connexion=new BDD('suivieent');
				$login=$_POST['login'];
				$mdp=$_POST['mdp'];
				$categorie=$_POST['categorie'];
				
				$requete="select e_code, login, mdp from $categorie where mdp='$mdp' and login='$login';";
				$tab=$connexion->select($requete);
				if($tab == null){
					$message= "Mot de passe ou nom de compte incorrectes";
				}
				else if($categorie=="etudiant"){
					session_start();
					$_SESSION['e_code']=$tab[0]["e_code"]; 
					header("location:lister/afficherempV2.php");
				}
				else if($categorie="enseignant") {
					session_start();
					$_SESSION['e_code']=$tab[0]["e_code"]; 
					header("location:lister/afficherempV1.php");
				}
		}
	?>