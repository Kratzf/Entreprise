<!DOCTYPE html>

<?php

session_start();
if (isset($_SESSION['e_code'])) {
	include ('afflist.php');
}			
else {
			header("location:../index.php");
		}
	?>
<html>
    <head>
        <meta charset="utf-8" />
        <title>PPE suivie entrprise</title>
        <link rel="stylesheet" href="../css/style1.css" />
    </head>
    <body>
	<header></header>
	<section>
	<h1>liste des entreprises</h1>
		<form action="liste_ent.php" method="post">
			<?php
				detail_entr();
			?>
		</form>
	</section>
    </body>
</html>


