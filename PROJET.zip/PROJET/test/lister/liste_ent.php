<!DOCTYPE html>

<?php
session_start();
//require 'afficherempV1.php';
if (isset($_SESSION['e_code'])) {
			include ('afflist.php');
		}
		else {
			header("location:../index.php");
		}
?>
<html>
    <head>
        <meta charset="utf-8" />
        <title>PPE suivie entrprise</title>
        <link rel="stylesheet" href="../css/style1.css" />
    </head>
    <body>
	<header></header>
	<section>
		<h1>liste des entreprises</h1>
		<form action="liste_ent.php" method="post">
		<?php

			if(isset($_GET['acc'])) {
				if($_GET['acc']=='list_ens') {
					list_ens();
				}
				else if($_GET['acc']=='list_etu') {
					list_etu();
				}
			}
		

		?>
	</form>
	</section>
    </body>
</html>


