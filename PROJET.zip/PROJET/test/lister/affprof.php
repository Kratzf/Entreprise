<?php
include 'BDD.php';
//include '../login.php';

	function rempprof() {
		$connexion=new BDD('suivieent');
		$e_code = $_SESSION['e_code'];
			$requete="select en_nom, en_prenom, login, mdp, en_mail, id_utilisateur
					from enseignant
					WHERE e_code=$e_code";
					//execution de la requete
					$tab=$connexion->select($requete);
					$ligne = $tab[0];
						$login=$ligne['login'];
						$mdp=$ligne['mdp'];
						$en_nom=$ligne['en_nom'];
						$en_prenom=$ligne['en_prenom'];
						$id_utilisateur=$ligne['id_utilisateur'];
						$en_mail=$ligne['en_mail'];
						
						echo "<span class='label'>Nom </span><span class='champ' name='en_nom'>$en_nom</span><br/>
						<span class='label'> Prénom </span><span class='champ' name='en_prenom'>$en_prenom</span><br /> 
						<span class='label'>Mail </span><span class='champ' name='en_mail'>$en_mail</span><br/>";
						
				return $tab;
	}
	
	function rempetu() {
		//include 'BDD.php';
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
			$requete="select et_nom, et_prenom, login, mdp, et_mail, id_utilisateur
				from etudiant
				WHERE e_code=$e_code";
				//echo $requete;
				$tab=$connexion->select($requete);
				$ligne = $tab[0];
					$login=$ligne['login'];
					$mdp=$ligne['mdp'];
					$et_nom=$ligne['et_nom'];
					$et_prenom=$ligne['et_prenom'];
					$id_utilisateur=$ligne['id_utilisateur'];
					$et_mail=$ligne['et_mail'];
					
					echo "<span class='label'>Nom </span><span class='champ' name='et_nom'>$et_nom</span><br/>
						<span class='label'> Prénom </span><span class='champ' name='et_prenom'>$et_prenom</span><br /> 
						<span class='label'>Mail </span><span class='champ' name='et_mail'>$et_mail</span><br/>";
						
			return $tab;					
	}
		
	?>	