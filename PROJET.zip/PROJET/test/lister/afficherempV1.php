<?php
session_start();

	
		if (isset($_SESSION['e_code'])) {
			include ('affprof.php');
		}
		else {
			header("location:../index.php");
		}
?>

 <!DOCTYPE html>
<html>
    <head>
		<meta charset="utf-8" />
		<title>Gestion des entreprises</title>
		<link rel="stylesheet" href="../css/style1.css" />
		<!--<link rel="stylesheet" href="../css/style1.css" />-->
	</head>
        
    <body>
		
	<header></header>
	<section>
		<h1>Bienvenue dans l'application de gestion des entreprises</h1>
		<p>
			<?php
				rempprof();
			?>
			Vous pouvez vous déconnecter:	<a href="deconnexion.php"> DECONNEXION</a>
		</p>
		
				</br><a href='../creer/creer_ent.php'>Creation entreprises</a>
				<a href='liste_ent.php?acc=list_ens'>Liste des entreprises</a>
				<a href='liste_ent_dem.php?accdem=list_ens'>Liste des entreprises_demandes</a>
	</section>	
 

</body>
</html>