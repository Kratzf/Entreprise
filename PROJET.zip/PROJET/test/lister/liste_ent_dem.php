<!DOCTYPE html>

<?php

session_start();
//require 'afficherempV1.php';
if (isset($_SESSION['e_code'])) {
			include ('affdem.php');
		}
		else {
			header("location:../index.php");
		}

?>
<html>
    <head>
        <meta charset="utf-8" />
        <title>PPE suivie entrprise</title>
        <link rel="stylesheet" href="../css/style1.css" />
    </head>
    <body>
	<header></header>
	<section>
		<h1>liste des entreprises_demandes</h1>
		<form action="liste_ent.php" method="post">
		<?php
			if(isset($_GET['accdem'])) {
					if($_GET['accdem']=='list_ens') {
						list_ensDem();
					}
					else if($_GET['accdem']=='list_etu') {
						list_etuDem();
					}
				}
		?>
		</form>
	</section>
    </body>
</html>


