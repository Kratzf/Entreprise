<?php
	include 'BDD.php';
	
function list_ens() {
	$connexion=new BDD('suivieent');
	$e_code = $_SESSION['e_code'];
	$message="";
	
	$requete="select * from entreprises
	Inner Join type_entreprises On entreprises.te_code=type_entreprises.te_code;";
	$tab = $connexion->select($requete);
	$tab=$connexion->select($requete);
//on recupère la taille du tableau
	$max=count($tab);
	
	echo "<table border='1'>";
	echo "<th>nom</th><th>adresse 1</th> <th>ville</th> <th>telephone</th><th> mail </th><th> libelle</th><th>Modifier</th> <th>Supprimer</th>";
	for($i=0;$i<$max;$i=$i+1){
			$ligne=$tab[$i];
		    echo "<tr>".
				 "<td><a href='detail_entr.php?id=",$ligne['e_code'],"'>",$ligne['e_nom'],"</a></td>".
				 "<td>",$ligne['e_adresse1'],"</td>".
				 "<td>",$ligne['e_ville'],"</td>".
				 "<td>",$ligne['e_tel'],"</td>".
				 "<td>",$ligne['e_mail'],"</td>".
				 "<td>",$ligne['te_libelle'],"</td>".
				 "<td> <a href='../modifier/modifier_ent.php?id=",$ligne['e_code'],"'>",$ligne['e_code'],"</a></td>".
				 "<td> <a href='../supprimer/suppr_entreprises.php?e_code=",$ligne['e_code'],"'>",$ligne['e_code'],"</a></td>".
				 "</tr>";
	}

echo"</table>";
echo $message;
}

function list_etu() {
	$connexion=new BDD('suivieent');
	$e_code = $_SESSION['e_code'];
	$message="";
	
	$requete="select * from entreprises
	Inner Join type_entreprises On entreprises.te_code=type_entreprises.te_code;";
	$tab = $connexion->select($requete);
	$max = count($tab);
	
	echo "<table border='1'>";
	echo "<th>nom</th><th>adresse 1</th> <th>ville</th> <th>telephone</th><th> mail </th><th> libelle</th>";
	for($i=0;$i<$max;$i=$i+1){
        $ligne=$tab[$i];
		
        echo "<tr>".
             "<td><a href='detail_entr.php?id=",$ligne['e_code'],"'>",$ligne['e_nom'],"</a></td>".
			 "<td>",$ligne['e_adresse1'],"</td>".
             "<td>",$ligne['e_ville'],"</td>".
			 "<td>",$ligne['e_tel'],"</td>".
			 "<td>",$ligne['e_mail'],"</td>".
			 "<td>",$ligne['te_libelle'],"</td>".
             "</tr>";
	}

echo"</table>";
echo $message;
}

function detail_entr() {
			$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
			if (isset($_GET['id'])) {
					$e_code = $_GET['id'];
				$message="";
				$requete="select * from entreprises
				Inner Join type_entreprises On entreprises.te_code=type_entreprises.te_code
				WHERE e_code=$e_code;";
				$tab = $connexion->select($requete);
				$max = count($tab);
				
				echo "<table border='1'>";
				echo "<th>Code</th><th>nom</th><th>adresse 1</th><th>adresse 2 <th>ville</th><th>CP</th><th>Nom_correspondant</th> <th>telephone</th><th> mail </th>
				<th>Statut</th><th> libelle</th>";
				for($i=0;$i<$max;$i=$i+1){
						$ligne=$tab[$i];
		
				echo "<tr>".
					"<td>",$ligne['e_code'],"</td>".
					 "<td>",$ligne['e_nom'],"</td>".
					 "<td>",$ligne['e_adresse1'],"</td>".
					 "<td>",$ligne['e_adresse2'],"</td>".
					 "<td>",$ligne['e_ville'],"</td>".
					 "<td>",$ligne['e_codpostal'],"</td>".
					 "<td>",$ligne['e_nom_correspondant'],"</td>".
					 "<td>",$ligne['e_tel'],"</td>".
					 "<td>",$ligne['e_mail'],"</td>".
					 "<td>",$ligne['e_statut'],"</td>".
					 "<td>",$ligne['te_libelle'],"</td>".
					 "</tr>";
				}

			echo"</table>";
			echo $message;
			}
}

function detail_entrDem() {
	$connexion=new BDD('suivieent');
			$e_code = $_SESSION['e_code'];
				if (isset($_GET['id'])) {
					$e_code_dem = $_GET['id'];
					$message="";
					
					$requete="select * from entreprises_demande
					Inner Join type_entreprises On entreprises_demande.te_code_dem=type_entreprises.te_code
					WHERE e_code_dem=$e_code_dem;";
					$tab = $connexion->select($requete);
					$max = count($tab);
					
					echo "<table border='1'>";
					echo "<th>Code</th><th>nom</th><th>adresse 1</th><th>adresse 2 <th>ville</th><th>CP</th><th>Nom_correspondant</th> <th>telephone</th><th> mail </th>
					<th>Statut</th><th> libelle</th><th>Modifier</th> <th>Supprimer</th>";
					
					for($i=0;$i<$max;$i=$i+1){
							$ligne=$tab[$i];
							
							echo "<tr>".
								"<td>",$ligne['e_code_dem'],"</td>".
								 "<td>",$ligne['e_nom_dem'],"</td>".
								 "<td>",$ligne['e_adresse1_dem'],"</td>".
								 "<td>",$ligne['e_adresse2_dem'],"</td>".
								 "<td>",$ligne['e_ville_dem'],"</td>".
								 "<td>",$ligne['e_codpostal_dem'],"</td>".
								 "<td>",$ligne['e_nom_correspondant_dem'],"</td>".
								 "<td>",$ligne['e_tel_dem'],"</td>".
								 "<td>",$ligne['e_mail_dem'],"</td>".
								 "<td>",$ligne['e_statut_dem'],"</td>".
								 "<td>",$ligne['te_libelle'],"</td>".
								 "</tr>";
}

echo"</table>";
echo $message;
}
}
	
?>