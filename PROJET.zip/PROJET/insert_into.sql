Insert into utilisateur(id_utilisateur, statut) values
(1,'etudiant'),
(2,'enseignant');

Insert into etudiant(e_code, login, mdp, et_nom, et_prenom, et_mail, id_utilisateur) values
(1, 'gachera', 'fdp1', 'gacher','aurelien','aurelien.gacher@laposte.net',1),
(2, 'litaisex', 'fdp2','litaise','xavier','xavier.litaise@laposte.net',1),
(3, 'kratzf', 'fdp3', 'kratz','florian','florian.kratz@laposte.net',1);

Insert into enseignant(e_code, login, mdp, en_nom, en_prenom, en_mail, id_utilisateur) values
(1, 'castillj', 'ndp1', 'castillo','jc','jc.castillo@laposte.net',2),
(2, 'fichec', 'ndp2', 'fiche','claude','claude.fiche@laposte.net',2),
(3, 'boucherb', 'ndp3', 'bouchereau','bertrand','bertrand.bouchereau@laposte.net',2);

Insert into type_entreprises (te_code, te_libelle) values
(1,'agriculture'),
(2,'informatique'),
(3,'communication');

Insert into entreprises (e_nom,e_adresse1,e_adresse2,e_ville,e_codpostal,e_nom_correspondant,e_tel,e_mail,e_statut,te_code) values
('eolane','11 rue des bois',"boisier",'Angers','17500','fanzer','0614527896','eolane@gmail.com','SARL',1),
('jouetClub','29 rue des sapins',"sainteté",'Saintes','17100','JJ','0614326598','JC@gmail.com','SARL',3),
('leclerc','14 avenue de la reine',"roc",'Rochefort','17200','LC','0614022558','leclerc@gmail.com','SARL',2);

Insert into entreprises_demande (e_nom_dem ,e_adresse1_dem ,e_adresse2_dem,e_ville_dem
,e_codpostal_dem, e_nom_correspondant_dem, e_tel_dem,e_mail_dem, e_statut_dem,  te_code_dem) values
('pokeworld','11 rue des rocket',"pika",'Perdue','79310','sacha','0512235689','pokeW@gmail.com','SA', 3),
('yugioh','29 rue des cartes',"ame",'Domino','81200','kaiba','0541748552','YGO@gmail.com','SA', 2),
('konoha','14 avenue de la foret',"clone",'Feu','69400','sasuke','0519378246','konoha@gmail.com','SA', 1);