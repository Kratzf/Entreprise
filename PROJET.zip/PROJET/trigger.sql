delimiter//
Create Trigger tr_entreprises_insert
	Before Insert | Update on entreprises for each row
Begin
	declare nb_entr int;
  select count(*) into nb_entr
  from entreprises
  where e_nom=new.e_nom;
  if(nb_entr>1) then
    insert into erreur(erreur) values ('Pas 2 entreprises avec le même nom');
  end if;
End;
//
delimiter ;

delimiter //
Create trigger tr_histo_entreprises
before delete on entreprises for each row
begin
  insert into histo_entreprises (
     e_code_histo
    ,e_nom_histo
    ,e_adresse1_histo
    ,e_adresse2_histo
    ,e_ville_histo
	,e_codpostal_histo
	,e_nom_correspondant_histo
	,e_tel_histo
	,e_mail_histo
	,e_statut_histo
	,te_code
  ) VALUES (
     old.e_code
    ,old.e_nom
    ,old.e_adresse1
    ,old.e_adresse2
    ,old.e_ville
	,old.e_codpostal
	,old.e_nom_correspondant
	,old.e_tel
	,old.e_mail
	,old.e_statut
	,old.te_code
  );
end;
//
delimiter ;

delete from entreprises where e_code=1;