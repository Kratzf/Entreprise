<!DOCTYPE html>
<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<?php
session_start();
if (isset($_SESSION['e_code'])) {
			include 'affcreerD.php';
			
}
else {
			header("location:../index.php");
		}
	?>
<html>
<head>
	<meta charset="utf-8" />
	<title>suivie entreprise</title>
</head>
<body>
	<h1>creer entreprise demande</h1>
	<form method="post" action="creer_ent_dem.php"> 
		
			nom: <input type="text" name='e_nom' id="nom" value="<?php echo $e_nom_dem; ?>"/>
			<span class="error-message"></span></br>
			
			adresse1: <input type="text" name='e_adresse1' id="adresse1" value="<?php echo $e_adresse1_dem; ?>" />
			<span class="error-message"></span></br>
			
			adresse2: <input type="text" name='e_adresse2' id="adresse2" value="<?php echo $e_adresse2_dem; ?>"/>
			<span class="error-message"></span></br>
			
			ville: <input type="text" name='e_ville' id="ville" value="<?php echo $e_ville_dem; ?>" />
			<span class="error-message"></span></br>
			
			code postal: <input type="text" name='e_codPostal' id="CP" value="<?php echo $e_codPostal_dem; ?>" />
			<span class="error-message"></span></br>
			
			nom correspondant: <input type="text" name='e_nom_correspondant' id="nom_correspondant" value="<?php echo $e_nom_correspondant_dem; ?>" />
			<span class="error-message"></span></br>
			
			telephone: <input type="text" name='e_tel' id='tel' value="<?php echo $e_tel_dem; ?>" />
			<span class="error-message"></span></br>
			
			mail: <input type="email" name='e_mail' id='mail' value="<?php echo $e_mail_dem; ?>" /></br>
			
			statut juridique (SARL, SA, ...): <input type="text" name='e_statut' id="statut" value="<?php echo $e_statut_dem; ?>" />
			<span class="error-message"></span></br>
			Le type de l'entreprise :	<select name="te_code_dem">
			<?php
						$sql="SELECT * FROM type_entreprises;";
						$tab=$connexion->select($sql);
						$max=count($tab);
						for($i=0;$i<$max;$i=$i+1){
						$ligne=$tab[$i];
						echo "<option value='",$ligne['te_code'],"'>",$ligne['te_libelle'],"</option>";
						}
			
			?>
			</select></br>
			<!--inserer la liste deroulante-->
		<input type="submit" name="envoyer" id="envoyer" value="Envoyer" onclick="validForm();"/></br>
		<input type="reset" name="annuler" id="annuler" />
	</form>
	<script src="../jquery.js"></script>
        <script src="../app.js"></script>
</body>
</html>
