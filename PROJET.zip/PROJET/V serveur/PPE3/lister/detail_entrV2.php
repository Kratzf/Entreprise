<?php
//utilisation du session_start pour pallier a toute tentative d'intrusion
session_start();
if (isset($_SESSION['e_code'])) {
			include '../BDD.php';
			$connexion=new BDD('entreprise');
			$e_code = $_SESSION['e_code'];
			if (isset($_GET['id'])) {
				$e_code = $_GET['id'];
				$message="";
				//récupération du e_code pour afficher les détails de la bonne entreprise
				$requete="select * from entreprises
				Inner Join type_entreprises On entreprises.te_code=type_entreprises.te_code
				WHERE e_code=$e_code;";
				$tab = $connexion->select($requete);
				$max = count($tab);

?>
<html>
<header>
<?php
include"../page/header.php";


?>
</header>
<body>
<?php
include"../page/nav2.php";
?>
    <head>
        <meta charset="utf-8" />
        <title>PPE suivie entrprise</title>
        <link rel="stylesheet" href="../CSS/style1.css" />
    </head>
	<h1>liste des entreprises</h1>
	<form action="liste_ent.php" method="post">
<?php
$tab=$connexion->select($requete);
//on recup?re la taille du tableau
$max=count($tab);
echo "<table border='1'>";
echo "<th>Code</th><th>nom</th><th>adresse 1</th><th>adresse 2 <th>ville</th><th>CP</th><th>Nom_correspondant</th> <th>telephone</th><th> mail </th>
<th>Statut</th><th> libelle</th>";
for($i=0;$i<$max;$i=$i+1){
        $ligne=$tab[$i];
		//on affiche le tout dans un tableau en récuperan les variables
        echo "<tr>".
			"<td>",$ligne['e_code'],"</td>".
             "<td>",$ligne['e_nom'],"</td>".
			 "<td>",$ligne['e_adresse1'],"</td>".
			 "<td>",$ligne['e_adresse2'],"</td>".
             "<td>",$ligne['e_ville'],"</td>".
			 "<td>",$ligne['e_codpostal'],"</td>".
			 "<td>",$ligne['e_nom_correspondant'],"</td>".
			 "<td>",$ligne['e_tel'],"</td>".
			 "<td>",$ligne['e_mail'],"</td>".
			 "<td>",$ligne['e_statut'],"</td>".
			 "<td>",$ligne['te_libelle'],"</td>".
             "</tr>";
}



echo"</table>";
echo $message;
			}
}
else {
			header("location:../login_ent.php");
		}
	?>
	</form>
    </body>
</html>


