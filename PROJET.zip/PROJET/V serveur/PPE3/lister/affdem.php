<?php
include 'BDD.php';

function list_ensDem() {
	$connexion=new BDD('suivieent');
	$e_code = $_SESSION['e_code'];
	$message="";
	
	$requete="select * from entreprises_demande
	Inner Join type_entreprises On entreprises_demande.te_code_dem=type_entreprises.te_code;";
	$tab = $connexion->select($requete);
	$max = count($tab);
	
	echo "<table border='1'>";
	echo "<th>nom</th><th>adresse 1</th> <th>ville</th> <th>telephone</th><th> mail </th><th> libelle</th><th>Modifier</th> <th>Supprimer</th>";
	for($i=0;$i<$max;$i=$i+1){
			$ligne=$tab[$i];
		     echo "<tr>".
				 "<td><a href='detail_entr_demV2.php?id=",$ligne['e_code_dem'],"'>",$ligne['e_nom_dem'],"</a></td>".
				 "<td>",$ligne['e_adresse1_dem'],"</td>".
				 "<td>",$ligne['e_ville_dem'],"</td>".
				 "<td>",$ligne['e_tel_dem'],"</td>".
				 "<td>",$ligne['e_mail_dem'],"</td>".
				// "<td>",$ligne['et_code'],"</td>".
				 "<td>",$ligne['te_libelle'],"</td>".
				 "<td> <a href='../modifier/modifier_ent_dem.php?id=",$ligne['e_code_dem'],"'>",$ligne['e_code_dem'],"</a></td>".
				 "<td> <a href='../supprimer/suppr_entreprises.php?e_code=",$ligne['e_code_dem'],"'>",$ligne['e_code_dem'],"</a></td>".
				 "</tr>";
	}
echo"</table>";
echo $message;
}

function list_etuDem() {
	$connexion=new BDD('suivieent');
	$e_code = $_SESSION['e_code'];
	$message="";
	
	$requete="select * from entreprises_demande
	Inner Join type_entreprises On entreprises_demande.te_code_dem=type_entreprises.te_code;";
	$tab = $connexion->select($requete);
	$max = count($tab);
	
	echo "<table border='1'>";
echo "<th>nom</th><th>adresse 1</th> <th>ville</th> <th>telephone</th><th> mail </th><th> libelle</th><th>Modifier</th>";
for($i=0;$i<$max;$i=$i+1){
        $ligne=$tab[$i];
		
        echo "<tr>".
             "<td><a href='detail_entr_demV2.php?id=",$ligne['e_code_dem'],"'>",$ligne['e_nom_dem'],"</a></td>".
			 "<td>",$ligne['e_adresse1_dem'],"</td>".
             "<td>",$ligne['e_ville_dem'],"</td>".
			 "<td>",$ligne['e_tel_dem'],"</td>".
			 "<td>",$ligne['e_mail_dem'],"</td>".
			// "<td>",$ligne['et_code'],"</td>".
			 "<td>",$ligne['te_libelle'],"</td>".
			 "<td> <a href='../modifier/modifier_ent_dem.php?id=",$ligne['e_code_dem'],"'>",$ligne['e_code_dem'],"</a></td>".
             "</tr>";
}
echo"</table>";
echo $message;
}

?>